// Verificar autenticación (solo admin y gerente)
const rol = localStorage.getItem('rol');
if (localStorage.getItem('loggedIn') !== 'true' || !['administrador', 'gerente'].includes(rol)) {
    window.location.href = '../login.html';
}

document.addEventListener('DOMContentLoaded', function() {
    // Cargar datos del usuario
    const usuario = localStorage.getItem('usuario');
    const userInfoElement = document.querySelector('.user-info');
    if (userInfoElement && usuario) {
        userInfoElement.textContent = `👤 ${usuario}, ${rol === 'administrador' ? 'Administrador' : 'Gerente'}`;
    }
    
    // Event listeners
    document.getElementById('exportarBtn').addEventListener('click', exportarReporte);
    document.getElementById('rangoFecha').addEventListener('change', cambiarRangoFecha);
    
    // Cargar datos iniciales
    cargarDatosReportes();
});

function cargarDatosReportes() {
    // Simular carga de datos desde el backend
    const rango = document.getElementById('rangoFecha').value;
    console.log('Cargando reportes para:', rango);
    
    // En producción, aquí harías una petición al backend
    // fetch(`/api/reportes?rango=${rango}`)
    
    // Simular datos
    setTimeout(() => {
        // Actualizar métricas basadas en el rango
        const metricas = {
            hoy: { ventas: '2,450,000', pedidos: '156', producto: 'Chuleta Valluna' },
            semana: { ventas: '8,750,000', pedidos: '420', producto: 'Sancocho de Gallina' },
            mes: { ventas: '32,100,000', pedidos: '1,250', producto: 'Hamburguesa Clásica' }
        };
        
        const data = metricas[rango] || metricas.hoy;
        
        document.querySelectorAll('.metric-value')[0].textContent = `$${data.ventas}`;
        document.querySelectorAll('.metric-value')[1].textContent = data.pedidos;
        document.querySelectorAll('.metric-value')[2].textContent = data.producto;
    }, 1000);
}

function cambiarRangoFecha() {
    cargarDatosReportes();
}

function exportarReporte() {
    const rango = document.getElementById('rangoFecha').value;
    
    // Simular exportación
    console.log('Exportando reporte para:', rango);
    
    // En producción, aquí harías una petición al backend para generar el PDF/Excel
    // fetch(`/api/reportes/exportar?rango=${rango}&formato=pdf`)
    
    alert(`Reporte para ${rango} exportado exitosamente!`);
}

// Event listeners para reportes rápidos
document.querySelectorAll('.report-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        const tipoReporte = this.textContent.trim();
        generarReporteRapido(tipoReporte);
    });
});

function generarReporteRapido(tipo) {
    console.log('Generando reporte rápido:', tipo);
    alert(`Generando reporte: ${tipo}`);
    
    // En producción, redirigiría o abriría un modal con el reporte específico
}