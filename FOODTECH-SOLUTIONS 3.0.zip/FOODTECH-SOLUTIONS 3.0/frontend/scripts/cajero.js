// Servicios específicos para cajero - DECLARACIÓN ÚNICA
const facturaService = {
    async generarFactura(pedidoId, facturaData) {
        return await apiService.generarFactura(pedidoId, facturaData);
    }
};

// ✅ FUNCIONES FALTANTES IMPLEMENTADAS
function obtenerPedidoIdActual() {
    // Implementación temporal - en producción esto vendría del pedido activo
    return Date.now();
}

function mostrarError(mensaje) {
    alert('❌ ' + mensaje);
}

function mostrarExito(mensaje) {
    alert('✅ ' + mensaje);
}

function actualizarTotales() {
    // Lógica para calcular totales del ticket
    const filas = document.querySelectorAll('.order-table tbody tr');
    let subtotal = 0;
    
    filas.forEach(fila => {
        const precioElement = fila.querySelector('td:nth-child(3)'); // Asumiendo que la columna 3 es precio
        const cantidadElement = fila.querySelector('td:nth-child(2)'); // Asumiendo que la columna 2 es cantidad
        
        if (precioElement && cantidadElement) {
            const precio = parseFloat(precioElement.textContent.replace('$', '')) || 0;
            const cantidad = parseInt(cantidadElement.textContent) || 0;
            subtotal += precio * cantidad;
        }
    });
    
    // Actualizar elementos en el DOM
    const subtotalElement = document.querySelector('.summary-item.subtotal span:last-child');
    const totalElement = document.querySelector('.summary-item.total span:last-child');
    
    if (subtotalElement) subtotalElement.textContent = '$' + subtotal.toFixed(2);
    if (totalElement) totalElement.textContent = '$' + subtotal.toFixed(2); // Por ahora total = subtotal
}

// Actualizar función de procesar pago
async function procesarPago() {
    const filas = document.querySelectorAll('.order-table tbody tr');
    
    if (filas.length === 0) {
        mostrarError('No hay productos en el ticket');
        return;
    }

    const totalElement = document.querySelector('.summary-item.total span:last-child');
    if (!totalElement) {
        mostrarError('No se puede calcular el total');
        return;
    }

    const total = totalElement.textContent;
    
    if (confirm(`¿Procesar pago por ${total}?`)) {
        try {
            const pedidoId = obtenerPedidoIdActual();
            
            const facturaData = {
                metodoPago: 'efectivo',
                idCajero: parseInt(localStorage.getItem('userId')) || 1
            };

            const factura = await facturaService.generarFactura(pedidoId, facturaData);
            
            mostrarExito(`Factura #${factura.numeroFactura} generada exitosamente!`);
            
            // Limpiar ticket
            const tbody = document.querySelector('.order-table tbody');
            if (tbody) tbody.innerHTML = '';
            actualizarTotales();
            
            // Generar nuevo número de ticket
            const ticketNum = document.querySelector('.ticket-header h3');
            if (ticketNum) {
                const currentMatch = ticketNum.textContent.match(/\d+/);
                const currentNum = currentMatch ? parseInt(currentMatch[0]) : 1;
                ticketNum.textContent = `Ticket de Venta #${String(currentNum + 1).padStart(4, '0')}`;
            }
            
        } catch (error) {
            console.error('Error procesando pago:', error);
            mostrarError('Error al procesar el pago: ' + error.message);
        }
    }
}

// ✅ INICIALIZACIÓN CORREGIDA
document.addEventListener('DOMContentLoaded', function() {
    // Verificar autenticación y rol
    if (!authService.isAuthenticated() || !authService.hasRole('cajero')) {
        authService.logout();
        window.location.href = 'login.html';
        return;
    }
    
    // Mostrar información del usuario
    const userInfo = authService.getCurrentUser();
    const userNameElement = document.getElementById('userName');
    if (userNameElement && userInfo) {
        userNameElement.textContent = userInfo.username || userInfo.usuario || 'Cajero';
    }
    
    // Configurar event listener para procesar pago
    const procesarPagoBtn = document.getElementById('procesarPagoBtn');
    if (procesarPagoBtn) {
        procesarPagoBtn.addEventListener('click', procesarPago);
    }
    
    // Configurar logout
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function() {
            authService.logout();
            window.location.href = 'login.html';
        });
    }
    
    // Inicializar totales
    actualizarTotales();
    
    console.log('Panel de Cajero inicializado correctamente');
});