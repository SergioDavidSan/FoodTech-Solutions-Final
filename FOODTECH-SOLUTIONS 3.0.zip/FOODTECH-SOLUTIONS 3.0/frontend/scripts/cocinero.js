// ✅ VERIFICACIÓN DE AUTENTICACIÓN MEJORADA - UNA SOLA VEZ
if (!authService.isAuthenticated() || !authService.hasRole('cocinero')) {
    authService.logout();
    window.location.href = '../login.html';
}

// ✅ SERVICIO PARA PEDIDOS (si no existe)
const pedidoService = {
    async getPedidosPorEstado(estado) {
        try {
            // Si tienes un endpoint específico por estado
            return await apiService.request(`/pedidos/estado/${estado}`);
        } catch (error) {
            console.error('Error obteniendo pedidos:', error);
            return [];
        }
    },

    async updatePedidoEstado(id, estado) {
        return await apiService.updatePedidoEstado(id, estado);
    },

    async marcarPedidoListo(id) {
        return await apiService.updatePedidoEstado(id, 'LISTO');
    }
};

// ✅ INICIALIZACIÓN PRINCIPAL - UNA SOLA VEZ
document.addEventListener('DOMContentLoaded', function() {
    // Cargar datos del usuario
    const userInfo = authService.getCurrentUser();
    const userInfoElement = document.querySelector('.user-info');
    if (userInfoElement && userInfo) {
        userInfoElement.textContent = `👨‍🍳 ${userInfo.username || userInfo.usuario || 'Cocinero'}`;
    }
    
    // Cargar pedidos activos
    cargarPedidosActivos();
    
    // Configurar event listeners delegados
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('btn-preparar')) {
            iniciarPreparacion(e.target);
        }
        if (e.target.classList.contains('btn-terminar')) {
            terminarPreparacion(e.target);
        }
    });

    // Configurar logout
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function() {
            authService.logout();
            window.location.href = '../login.html';
        });
    }
});

// ✅ FUNCIÓN PARA CARGAR PEDIDOS ACTIVOS
async function cargarPedidosActivos() {
    try {
        console.log('🔄 Cargando pedidos activos...');
        const pedidos = await pedidoService.getPedidosPorEstado('PENDIENTE');
        actualizarVistaPedidos(pedidos);
        actualizarEstadisticas();
    } catch (error) {
        console.error('Error cargando pedidos:', error);
        // Mostrar mensaje de error al usuario
        mostrarError('No se pudieron cargar los pedidos');
    }
}

// ✅ ACTUALIZAR VISTA DE PEDIDOS
function actualizarVistaPedidos(pedidos) {
    const contenedorPedidos = document.querySelector('.pedidos-container');
    if (!contenedorPedidos) return;

    if (pedidos.length === 0) {
        contenedorPedidos.innerHTML = '<p class="no-pedidos">No hay pedidos pendientes</p>';
        return;
    }

    contenedorPedidos.innerHTML = pedidos.map(pedido => `
        <div class="pedido-card pendiente" data-pedido-id="${pedido.id}">
            <div class="pedido-header">
                <h3>Pedido #${pedido.numeroPedido || pedido.id}</h3>
                <span class="estado-badge pendiente">${pedido.estado || 'Pendiente'}</span>
            </div>
            <div class="pedido-info">
                <p><strong>Mesa:</strong> ${pedido.mesa || 'N/A'}</p>
                <p><strong>Hora:</strong> ${new Date(pedido.fechaCreacion).toLocaleTimeString()}</p>
            </div>
            <div class="items-list">
                ${(pedido.items || []).map(item => `
                    <div class="item">
                        <span>${item.cantidad}x ${item.nombreProducto}</span>
                        <div class="item-actions">
                            <button class="btn-preparar">Preparar</button>
                        </div>
                    </div>
                `).join('')}
            </div>
        </div>
    `).join('');
}

// ✅ INICIAR PREPARACIÓN
async function iniciarPreparacion(btn) {
    const item = btn.closest('.item');
    const pedidoCard = btn.closest('.pedido-card');
    const pedidoId = pedidoCard.dataset.pedidoId;
    
    if (!pedidoId) {
        console.error('No se encontró ID del pedido');
        return;
    }

    // Cambiar estado visual inmediatamente
    btn.textContent = 'Preparando...';
    btn.disabled = true;
    
    try {
        // Actualizar estado en backend
        await pedidoService.updatePedidoEstado(pedidoId, 'EN_PREPARACION');
        
        // Actualizar UI
        const estadoBadge = pedidoCard.querySelector('.estado-badge');
        if (estadoBadge) {
            estadoBadge.textContent = 'En Preparación';
            estadoBadge.className = 'estado-badge preparacion';
        }
        
        // Simular tiempo de preparación (en producción esto sería real)
        setTimeout(() => {
            if (item && item.parentNode) {
                item.innerHTML = `
                    <span>${item.querySelector('span')?.textContent || 'Item'}</span>
                    <div class="tiempo-preparacion">
                        <span>✅ Listo</span>
                        <button class="btn-terminar">Entregar</button>
                    </div>
                `;
            }
        }, 5000); // 5 segundos de simulación
        
    } catch (error) {
        console.error('Error iniciando preparación:', error);
        // Revertir cambios visuales
        btn.textContent = 'Preparar';
        btn.disabled = false;
        mostrarError('Error al iniciar preparación');
    }
}

// ✅ TERMINAR PREPARACIÓN
async function terminarPreparacion(btn) {
    const item = btn.closest('.item');
    const pedidoCard = btn.closest('.pedido-card');
    const pedidoId = pedidoCard.dataset.pedidoId;
    
    if (!pedidoId) {
        console.error('No se encontró ID del pedido');
        return;
    }

    try {
        // Marcar como listo en backend
        await pedidoService.marcarPedidoListo(pedidoId);
        
        // Eliminar item de la vista
        if (item) {
            item.remove();
        }
        
        // Verificar si todos los items están listos
        const itemsRestantes = pedidoCard.querySelectorAll('.item');
        
        if (itemsRestantes.length === 0) {
            // Todo el pedido está listo
            pedidoCard.style.opacity = '0.6';
            const estadoBadge = pedidoCard.querySelector('.estado-badge');
            if (estadoBadge) {
                estadoBadge.textContent = 'Completado';
                estadoBadge.className = 'estado-badge completado';
            }
            
            // Remover después de un tiempo
            setTimeout(() => {
                if (pedidoCard.parentNode) {
                    pedidoCard.remove();
                    actualizarEstadisticas();
                }
            }, 2000);
        }
        
        actualizarEstadisticas();
        
    } catch (error) {
        console.error('Error terminando preparación:', error);
        mostrarError('Error al terminar preparación');
    }
}

// ✅ ACTUALIZAR ESTADÍSTICAS
function actualizarEstadisticas() {
    try {
        const pedidosPendientes = document.querySelectorAll('.pedido-card.pendiente:not([style*="opacity: 0.6"])').length;
        const enPreparacion = document.querySelectorAll('.pedido-card.preparacion:not([style*="opacity: 0.6"])').length;
        const pedidosCompletados = document.querySelectorAll('.estado-badge.completado').length;
        
        const statNumbers = document.querySelectorAll('.stat-number');
        if (statNumbers.length >= 3) {
            statNumbers[0].textContent = pedidosPendientes;
            statNumbers[1].textContent = enPreparacion;
            statNumbers[2].textContent = pedidosCompletados;
        }
    } catch (error) {
        console.error('Error actualizando estadísticas:', error);
    }
}

// ✅ FUNCIÓN PARA MOSTRAR ERRORES
function mostrarError(mensaje) {
    // Puedes implementar un sistema de notificaciones más elegante
    console.error('❌ ' + mensaje);
    alert('❌ ' + mensaje);
}

// ✅ FUNCIÓN PARA MOSTRAR ÉXITO
function mostrarExito(mensaje) {
    console.log('✅ ' + mensaje);
    // Puedes implementar notificaciones toast
}