// Espera a que el contenido del DOM esté cargado
document.addEventListener("DOMContentLoaded", () => {
    
    // Obtenemos el formulario y el spinner
    const registerForm = document.getElementById("register-form");
    const spinner = document.getElementById("btn-spinner");
    const btnText = document.getElementById("btn-text");

    // Verificamos que los servicios estén disponibles (igual que en login.js)
    if (typeof authService === 'undefined') {
        console.error('Error: authService no está definido.');
    }
    if (typeof apiService === 'undefined') {
        console.error('Error: apiService no está definido.');
    }

    // Añadimos el "escuchador" al formulario
    registerForm.addEventListener("submit", async (e) => {
        e.preventDefault(); // Evita que la página se recargue

        // Mostramos el spinner
        spinner.style.display = "inline-block";
        btnText.textContent = "Registrando...";

        // Obtenemos los datos del formulario
        const rol = document.getElementById("rol").value;
        const usuario = document.getElementById("usuario").value;
        const email = document.getElementById("email").value;
        const contrasena = document.getElementById("contrasena").value;

        // Creamos el objeto de datos para enviar
        const registroData = {
            nombreUsuario: usuario,
            contrasena: contrasena,
            email: email,
            rol: rol
        };
        
        console.log("🔄 Intentando registro con:", registroData);

        try {
            // Llamamos al método de registro en authService (que usa la API)
            // Asumimos que la API está en /api/auth/register
            const response = await authService.register(registroData);

            if (response.success) {
                console.log("✅ Registro exitoso:", response.data);
                alert("¡Usuario registrado con éxito! Ahora puedes iniciar sesión.");
                // Redirigimos al login
                window.location.href = "login.html";
            } else {
                console.error("❌ Registro fallido:", response.error);
                alert(`Error al registrar: ${response.error}`);
            }

        } catch (error) {
            console.error("❌ Error fatal en el registro:", error);
            alert("Error de conexión al intentar registrar. Revisa la consola.");
        } finally {
            // Ocultamos el spinner
            spinner.style.display = "none";
            btnText.textContent = "Registrarme";
        }
    });

    console.log("🎯 register.js cargado correctamente");
});