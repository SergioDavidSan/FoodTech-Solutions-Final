// ✅ SERVICIOS - DEFINIR UNA SOLA VEZ

const mesaService = {
    async getMesas() {
        return await apiService.getMesas();
    },

    async getMesasDisponibles() {
        try {
            // Si no existe un endpoint específico, filtrar las mesas
            const mesas = await apiService.getMesas();
            return mesas.filter(mesa => mesa.estado === 'disponible');
        } catch (error) {
            console.error('Error obteniendo mesas disponibles:', error);
            return [];
        }
    },

    async updateMesaEstado(id, estado) {
        return await apiService.updateMesaEstado(id, estado);
    },

    async ocuparMesa(id) {
        return await this.updateMesaEstado(id, 'ocupada');
    },

    async liberarMesa(id) {
        return await this.updateMesaEstado(id, 'disponible');
    }
};

const pedidoService = {
    async crearPedido(pedidoData) {
        return await apiService.crearPedido(pedidoData);
    },

    async getPedidosActivos() {
        return await apiService.getPedidosActivos();
    },

    async updatePedidoEstado(id, estado) {
        return await apiService.updatePedidoEstado(id, estado);
    }
};

const productoService = {
    async getProductosDisponibles() {
        return await apiService.getProductosDisponibles();
    }
};

// ✅ VARIABLES GLOBALES
let mesaSeleccionada = null;
let pedidoActual = [];

// ✅ FUNCIONES PRINCIPALES
async function cargarMesas() {
    try {
        console.log('🔄 Cargando mesas...');
        const mesas = await mesaService.getMesas();
        actualizarVistaMesas(mesas);
    } catch (error) {
        console.error('Error cargando mesas:', error);
        mostrarError('Error al cargar las mesas');
    }
}

async function cargarProductos() {
    try {
        console.log('🔄 Cargando productos...');
        const productos = await productoService.getProductosDisponibles();
        actualizarVistaProductos(productos);
    } catch (error) {
        console.error('Error cargando productos:', error);
        mostrarError('Error al cargar el menú');
    }
}

async function enviarACocina() {
    if (!mesaSeleccionada || pedidoActual.length === 0) {
        mostrarError('Por favor selecciona una mesa y agrega productos');
        return;
    }

    try {
        const pedidoData = {
            idMesa: parseInt(mesaSeleccionada),
            idUsuario: parseInt(localStorage.getItem('userId') || 1),
            detalles: pedidoActual.map(item => ({
                idProducto: item.idProducto,
                cantidad: item.cantidad,
                precioUnitario: item.precio,
                subtotal: item.precio * item.cantidad,
                notas: item.notas || ''
            })),
            total: pedidoActual.reduce((sum, item) => sum + (item.precio * item.cantidad), 0)
        };

        console.log('📤 Enviando pedido a cocina:', pedidoData);
        
        const resultado = await pedidoService.crearPedido(pedidoData);
        
        // Actualizar estado de la mesa
        await mesaService.ocuparMesa(parseInt(mesaSeleccionada));
        
        mostrarExito(`✅ Pedido #${resultado.idPedido} enviado a cocina exitosamente!`);
        nuevoPedido();
        
    } catch (error) {
        console.error('Error enviando pedido:', error);
        mostrarError('Error al enviar el pedido a cocina: ' + error.message);
    }
}

function nuevoPedido() {
    mesaSeleccionada = null;
    pedidoActual = [];
    
    // Limpiar selección de mesa
    document.querySelectorAll('.mesa-item').forEach(mesa => {
        mesa.classList.remove('selected');
    });
    
    // Limpiar lista de pedidos
    const orderList = document.querySelector('.order-list');
    if (orderList) {
        orderList.innerHTML = '';
    }
    
    // Actualizar total
    actualizarTotal();
    
    console.log('🆕 Nuevo pedido iniciado');
}

function actualizarTotal() {
    const total = pedidoActual.reduce((sum, item) => sum + (item.precio * item.cantidad), 0);
    const totalElement = document.querySelector('.order-total');
    if (totalElement) {
        totalElement.textContent = `Total: $${total.toFixed(2)}`;
    }
}

// ✅ FUNCIONES DE VISTA (necesitan ser implementadas)
function actualizarVistaMesas(mesas) {
    const mesasContainer = document.querySelector('.mesas-container');
    if (!mesasContainer) return;

    mesasContainer.innerHTML = mesas.map(mesa => `
        <div class="mesa-item ${mesa.estado === 'ocupada' ? 'ocupada' : 'disponible'}" 
             data-mesa-id="${mesa.idMesa}">
            <div class="mesa-numero">Mesa ${mesa.numeroMesa}</div>
            <div class="mesa-estado">${mesa.estado}</div>
            <div class="mesa-capacidad">${mesa.capacidad} personas</div>
        </div>
    `).join('');

    // Agregar event listeners a las mesas
    document.querySelectorAll('.mesa-item').forEach(mesa => {
        mesa.addEventListener('click', function() {
            if (!this.classList.contains('ocupada')) {
                seleccionarMesa(this.dataset.mesaId);
            }
        });
    });
}

function actualizarVistaProductos(productos) {
    const menuContainer = document.querySelector('.menu-container');
    if (!menuContainer) return;

    menuContainer.innerHTML = productos.map(producto => `
        <div class="producto-item" data-producto-id="${producto.idProducto}">
            <div class="producto-info">
                <h4>${producto.nombreProducto}</h4>
                <p class="producto-descripcion">${producto.descripcion || ''}</p>
                <p class="producto-precio">$${producto.precio}</p>
            </div>
            <button class="btn-agregar">Agregar</button>
        </div>
    `).join('');

    // Agregar event listeners a los productos
    document.querySelectorAll('.btn-agregar').forEach(btn => {
        btn.addEventListener('click', function() {
            const productoItem = this.closest('.producto-item');
            agregarProductoAlPedido(productoItem.dataset.productoId);
        });
    });
}

function seleccionarMesa(mesaId) {
    mesaSeleccionada = mesaId;
    
    // Actualizar UI
    document.querySelectorAll('.mesa-item').forEach(mesa => {
        mesa.classList.remove('selected');
    });
    
    const mesaSeleccionadaElement = document.querySelector(`[data-mesa-id="${mesaId}"]`);
    if (mesaSeleccionadaElement) {
        mesaSeleccionadaElement.classList.add('selected');
    }
    
    console.log(`🍽️ Mesa ${mesaId} seleccionada`);
}

function agregarProductoAlPedido(productoId) {
    if (!mesaSeleccionada) {
        mostrarError('Por favor selecciona una mesa primero');
        return;
    }

    // Buscar producto en los datos cargados
    const productoElement = document.querySelector(`[data-producto-id="${productoId}"]`);
    if (!productoElement) return;

    const nombre = productoElement.querySelector('h4').textContent;
    const precioText = productoElement.querySelector('.producto-precio').textContent;
    const precio = parseFloat(precioText.replace('$', ''));

    // Verificar si el producto ya está en el pedido
    const productoExistente = pedidoActual.find(item => item.idProducto == productoId);
    
    if (productoExistente) {
        productoExistente.cantidad += 1;
    } else {
        pedidoActual.push({
            idProducto: productoId,
            nombre: nombre,
            precio: precio,
            cantidad: 1,
            notas: ''
        });
    }

    actualizarVistaPedido();
    actualizarTotal();
}

function actualizarVistaPedido() {
    const orderList = document.querySelector('.order-list');
    if (!orderList) return;

    orderList.innerHTML = pedidoActual.map(item => `
        <div class="order-item" data-producto-id="${item.idProducto}">
            <div class="item-info">
                <span class="item-name">${item.nombre}</span>
                <span class="item-price">$${item.precio} x ${item.cantidad}</span>
            </div>
            <div class="item-actions">
                <button class="btn-remove">❌</button>
                <button class="btn-increase">➕</button>
            </div>
        </div>
    `).join('');

    // Agregar event listeners a los botones
    document.querySelectorAll('.btn-remove').forEach(btn => {
        btn.addEventListener('click', function() {
            const itemElement = this.closest('.order-item');
            removerProductoDelPedido(itemElement.dataset.productoId);
        });
    });

    document.querySelectorAll('.btn-increase').forEach(btn => {
        btn.addEventListener('click', function() {
            const itemElement = this.closest('.order-item');
            aumentarCantidadProducto(itemElement.dataset.productoId);
        });
    });
}

function removerProductoDelPedido(productoId) {
    pedidoActual = pedidoActual.filter(item => item.idProducto != productoId);
    actualizarVistaPedido();
    actualizarTotal();
}

function aumentarCantidadProducto(productoId) {
    const producto = pedidoActual.find(item => item.idProducto == productoId);
    if (producto) {
        producto.cantidad += 1;
        actualizarVistaPedido();
        actualizarTotal();
    }
}

// ✅ FUNCIONES DE UTILIDAD
function mostrarError(mensaje) {
    console.error('❌ ' + mensaje);
    // En producción, usar un sistema de notificaciones
    alert('❌ ' + mensaje);
}

function mostrarExito(mensaje) {
    console.log('✅ ' + mensaje);
    alert('✅ ' + mensaje);
}

// ✅ INICIALIZACIÓN - UNA SOLA VEZ
document.addEventListener('DOMContentLoaded', function() {
    // Verificar autenticación
    if (!authService.isAuthenticated() || !authService.hasRole('mesero')) {
        authService.logout();
        window.location.href = '../login.html';
        return;
    }

    // Mostrar información del usuario
    const userInfo = authService.getCurrentUser();
    const userNameElement = document.getElementById('userName');
    if (userNameElement && userInfo) {
        userNameElement.textContent = userInfo.username || userInfo.usuario || 'Mesero';
    }

    // Cargar datos iniciales
    cargarMesas();
    cargarProductos();
    
    // Configurar event listeners
    const enviarCocinaBtn = document.getElementById('enviarCocinaBtn');
    if (enviarCocinaBtn) {
        enviarCocinaBtn.addEventListener('click', enviarACocina);
    }
    
    const cancelarPedidoBtn = document.getElementById('cancelarPedidoBtn');
    if (cancelarPedidoBtn) {
        cancelarPedidoBtn.addEventListener('click', nuevoPedido);
    }

   // ✅ Configurar logout correctamente (UNA SOLA VEZ)
const logoutBtn = document.getElementById('logout-button');

if (logoutBtn) {
    logoutBtn.addEventListener('click', () => {
        // Limpiar sesión
        localStorage.removeItem('token');
        localStorage.removeItem('usuario');
        localStorage.removeItem('rol');

        // Redirigir al login
        window.location.href = "";
    });
}

});