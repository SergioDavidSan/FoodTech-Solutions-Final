package com.foodtech.controller;

import java.time.LocalDate;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.foodtech.services.ReporteService;

@RestController
@RequestMapping("/reportes")
@CrossOrigin(origins = "*")
@SuppressWarnings({"java:S6813", "java:S1452"})
public class ReporteController {
    
    @Autowired
    private ReporteService reporteService;
    
    @GetMapping("/ventas")
    public ResponseEntity<Map<String, Object>> generarReporteVentas(
            @RequestParam(required = false) String fechaInicio,
            @RequestParam(required = false) String fechaFin) {
        
        LocalDate inicio = fechaInicio != null ? LocalDate.parse(fechaInicio) : LocalDate.now().minusDays(30);
        LocalDate fin = fechaFin != null ? LocalDate.parse(fechaFin) : LocalDate.now();
        
        Map<String, Object> reporte = reporteService.generarReporteVentas(inicio, fin);
        return ResponseEntity.ok(reporte);
    }
    
    @GetMapping("/estadisticas")
    public ResponseEntity<Map<String, Object>> obtenerEstadisticasDiarias() {
        Map<String, Object> estadisticas = reporteService.obtenerEstadisticasDiarias();
        return ResponseEntity.ok(estadisticas);
    }
}