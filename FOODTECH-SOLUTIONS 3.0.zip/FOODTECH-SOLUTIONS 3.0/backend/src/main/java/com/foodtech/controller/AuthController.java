package com.foodtech.controller;

import com.foodtech.model.Role; 
import com.foodtech.model.Usuario; 
import com.foodtech.model.Usuario.EstadoUsuario; 
import com.foodtech.repository.RoleRepository;
import com.foodtech.services.UsuarioService;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Map; // <-- Importación para Map
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
@RestController
@RequestMapping("/api/auth")
// (¡OJO! Asegúrate de que tu puerto 5500 esté en la lista, el 52160 ya no lo usas)
@CrossOrigin(origins = {"http://localhost:5500", "http://127.0.0.1:5500"}) 
public class AuthController {

    private final AuthenticationManager authenticationManager;
    private final UsuarioService usuarioService;
    private final PasswordEncoder passwordEncoder;
    private final RoleRepository roleRepository; 
    private static final Logger log = LoggerFactory.getLogger(AuthController.class);
    public AuthController(AuthenticationManager authenticationManager, 
                          UsuarioService usuarioService, 
                          PasswordEncoder passwordEncoder,
                          RoleRepository roleRepository) { 
        this.authenticationManager = authenticationManager;
        this.usuarioService = usuarioService;
        this.passwordEncoder = passwordEncoder;
        this.roleRepository = roleRepository; 
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest loginRequest) {
        // (El código de Login sigue igual)
        try {
             log.info("Intento de login para el usuario: {}", loginRequest.getUsername());
             log.info("Intento de login para la contraseña: {}", loginRequest.getPassword());
            Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                    loginRequest.getUsername(),
                    loginRequest.getPassword()
                )
            );
            User user = (User) authentication.getPrincipal();
            log.info("Usuario encontrado: {}", user);

            String role = user.getAuthorities().stream()
                .findFirst()
                .map(GrantedAuthority::getAuthority)
                .orElse("USER")
                .replace("ROLE_", "");
            
            String token = "foodtech-token-" + System.currentTimeMillis(); 
            
            // --- CORRECCIÓN DE SINTAXIS Map.of ---
            return ResponseEntity.ok(Map.of(
                "token", token,
                "username", user.getUsername(),
                "role", role.toLowerCase(),
                "message", "Login exitoso"
            ));
        } catch (AuthenticationException e) {
            log.error("Error de autenticacion",e);
            return ResponseEntity.status(401).body(Map.of(
                "error", "Credenciales inválidas",
                "message", "Usuario o contraseña incorrectos"
            ));
        }
    }

    // --- MÉTODO DE REGISTRO 100% CORREGIDO ---
    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@RequestBody RegistroRequest registroRequest) {
        
        System.out.println("=========================================");
        System.out.println("AUTH_CONTROLLER: ¡Petición de registro RECIBIDA!");
        System.out.println("Usuario: " + registroRequest.getNombreUsuario());
        System.out.println("=========================================");

        try {
            // --- VALIDACIÓN ---
            if (usuarioService.existePorNombreUsuario(registroRequest.getNombreUsuario())) {
                return ResponseEntity.status(400).body(Map.of("message", "Error: El nombre de usuario ya existe."));
            }
            if (usuarioService.existePorEmail(registroRequest.getEmail())) {
                return ResponseEntity.status(400).body(Map.of("message", "Error: El email ya está registrado."));
            }
            
            // --- BUSCAR EL ROL ---
            String nombreRolBuscado = registroRequest.getRol().toUpperCase(); 
            
            Role rolObjeto = roleRepository.findByNombreRol(nombreRolBuscado) 
                .orElseThrow(() -> new RuntimeException("Error: El Rol '" + nombreRolBuscado + "' no se encontró en la base de datos."));

            // --- CREACIÓN DE USUARIO ---
            Usuario nuevoUsuario = new Usuario();
            nuevoUsuario.setNombreUsuario(registroRequest.getNombreUsuario());
            nuevoUsuario.setEmail(registroRequest.getEmail());
            nuevoUsuario.setContrasena(passwordEncoder.encode(registroRequest.getContrasena()));
            nuevoUsuario.setEstado(EstadoUsuario.activo); // Usamos el Enum
            nuevoUsuario.setRol(rolObjeto); // Asignamos el objeto Role encontrado
            
            Usuario usuarioGuardado = usuarioService.guardar(nuevoUsuario);

            // --- CORRECCIÓN DE SINTAXIS Map.of ---
            return ResponseEntity.ok(Map.of(
                "idUsuario", usuarioGuardado.getIdUsuario(),
                "username", usuarioGuardado.getNombreUsuario(),
                "message", "Usuario registrado exitosamente"
            ));

        } catch (Exception e) {
            System.err.println("Error en /register: " + e.getMessage());
            // --- CORRECCIÓN DE SINTAXIS Map.of ---
            return ResponseEntity.status(400).body(Map.of(
                "error", "Error en el registro",
                "message", e.getMessage() 
            ));
        }
    }

    @GetMapping("/health")
    public ResponseEntity<?> health() {
        return ResponseEntity.ok(Map.of(
            "status", "OK",
            "service", "FoodTech Auth Service",
            "timestamp", System.currentTimeMillis()
        ));
    }
}

// --- CLASES DTO (Sin cambios) ---
class LoginRequest {
    private String username;
    private String password;
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
}

class RegistroRequest {
    private String nombreUsuario;
    private String contrasena;
    private String email;
    private String rol;
    
    public String getNombreUsuario() { return nombreUsuario; }
    public void setNombreUsuario(String nombreUsuario) { this.nombreUsuario = nombreUsuario; }
    public String getContrasena() { return contrasena; }
    public void setContrasena(String contrasena) { this.contrasena = contrasena; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getRol() { return rol; }
    public void setRol(String rol) { this.rol = rol; }
}